package in.ac.famt.GDriveAccess34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GDriveAccess34Application {

	public static void main(String[] args) {
		SpringApplication.run(GDriveAccess34Application.class, args);
	}

}
